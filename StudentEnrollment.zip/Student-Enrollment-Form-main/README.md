# Student-Enrollment-Form
Basic Student Enrollment form using HTML-CSS-Bootstrap and JavaScript


# Screenshot
![Screenshot (48)](https://user-images.githubusercontent.com/67331152/132752497-11201e2d-70a5-428a-94ca-283d14882f27.png)
